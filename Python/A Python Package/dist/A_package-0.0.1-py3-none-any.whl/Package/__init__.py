def packagefunction(a, b):
    print("This is your answer")
    print((a+b)/2)



